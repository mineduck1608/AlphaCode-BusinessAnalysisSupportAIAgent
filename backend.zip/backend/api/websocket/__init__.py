"""WebSocket module for real-time communication."""
