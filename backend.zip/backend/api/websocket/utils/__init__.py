"""WebSocket utilities package."""
